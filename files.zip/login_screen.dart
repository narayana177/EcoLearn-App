import 'package:flutter/material.dart';

import '../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  final AuthService authService;

  const LoginScreen({super.key, required this.authService});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  AuthStatus _status = AuthStatus.idle;
  String? _message;

  Future<void> _handleGoogleSignIn() async {
    setState(() {
      _status = AuthStatus.loading;
      _message = 'Signing in…';
    });

    final result = await widget.authService.signInWithGoogle();
    if (!mounted) return;

    setState(() {
      _status = result.status;
      _message = result.message;
    });

    // On success, AuthGate's stream listener swaps to Home automatically —
    // nothing else to do here.
  }

  Color _messageColor() {
    switch (_status) {
      case AuthStatus.error:
      case AuthStatus.noInternet:
        return Colors.red.shade700;
      case AuthStatus.success:
        return Colors.green.shade700;
      default:
        return Colors.black54;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = _status == AuthStatus.loading;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'EcoLearn',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 48),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: OutlinedButton.icon(
                    onPressed: isLoading ? null : _handleGoogleSignIn,
                    icon: isLoading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const _GoogleGIcon(size: 18),
                    label: Text(
                      isLoading ? 'Signing in…' : 'Continue with Google',
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.black87,
                      side: const BorderSide(color: Color(0xFFDADCE0)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                if (_message != null) ...[
                  const SizedBox(height: 16),
                  Text(
                    _message!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: _messageColor()),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Lightweight multi-color "G" mark drawn in code, so the button doesn't
/// need a network image or a bundled asset to render correctly offline.
/// Swap this for Google's official logo asset (per Google's brand
/// guidelines) before shipping to the app stores.
class _GoogleGIcon extends StatelessWidget {
  final double size;
  const _GoogleGIcon({this.size = 18});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _GoogleGPainter()),
    );
  }
}

class _GoogleGPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final strokeWidth = size.width * 0.22;
    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.butt;
    final rect = Rect.fromLTWH(0, 0, size.width, size.height)
        .deflate(strokeWidth / 2);

    paint.color = const Color(0xFF4285F4);
    canvas.drawArc(rect, -0.3, 1.6, false, paint);
    paint.color = const Color(0xFF34A853);
    canvas.drawArc(rect, 1.3, 1.6, false, paint);
    paint.color = const Color(0xFFFBBC05);
    canvas.drawArc(rect, 2.9, 1.2, false, paint);
    paint.color = const Color(0xFFEA4335);
    canvas.drawArc(rect, 4.1, 1.6, false, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
