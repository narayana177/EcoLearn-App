import 'package:flutter/material.dart';

import '../services/auth_service.dart';

/// Drop this ListTile into the existing Profile/Settings screen. It's
/// self-contained and doesn't require restructuring that screen —
/// just add `LogoutTile(authService: authService)` wherever it should
/// appear in the settings list.
class LogoutTile extends StatelessWidget {
  final AuthService authService;

  const LogoutTile({super.key, required this.authService});

  Future<void> _confirmAndSignOut(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Log out?'),
        content: const Text('You can sign back in with Google anytime.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Log out'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await authService.signOut();
      // AuthGate's stream listener swaps back to LoginScreen
      // automatically once signOut() completes.
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.logout, color: Colors.red),
      title: const Text('Log out', style: TextStyle(color: Colors.red)),
      onTap: () => _confirmAndSignOut(context),
    );
  }
}
