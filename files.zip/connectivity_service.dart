import 'package:connectivity_plus/connectivity_plus.dart';

/// Thin wrapper around connectivity_plus so the rest of the auth code
/// doesn't need to know which package is used for connectivity checks.
class ConnectivityService {
  final Connectivity _connectivity;

  ConnectivityService({Connectivity? connectivity})
      : _connectivity = connectivity ?? Connectivity();

  /// True if the device currently has a network interface up.
  /// This checks for a connection, not guaranteed internet reachability —
  /// enough to gate "first login requires internet" without adding a
  /// ping/DNS round trip.
  Future<bool> hasConnection() async {
    final results = await _connectivity.checkConnectivity();
    return results.any((r) => r != ConnectivityResult.none);
  }
}
