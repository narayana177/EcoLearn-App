import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../screens/login_screen.dart';
import '../services/auth_service.dart';

/// Use this as (or inside) the widget that currently decides Login vs.
/// Home. It only swaps between LoginScreen and the HomeScreen you pass
/// in — Semester, Subject, Notes, Exam Papers and Offline Download
/// screens are untouched.
class AuthGate extends StatelessWidget {
  final Widget homeScreen;
  final AuthService authService;

  const AuthGate({
    super.key,
    required this.homeScreen,
    required this.authService,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: authService.authStateChanges,
      // Seeding with the cached user avoids a login-screen flash on
      // relaunch, and works fully offline since it comes from local
      // secure storage, not a network call.
      initialData: authService.currentUser,
      builder: (context, snapshot) {
        final user = snapshot.data;
        if (user != null) {
          return homeScreen;
        }
        return LoginScreen(authService: authService);
      },
    );
  }
}
