# EcoLearn — Google Authentication (Flutter)

Self-contained slice implementing Google sign-in via Firebase Auth. Nothing
here touches Semester, Subject, Exam Papers, Notes, or Offline Download code
— it only adds sign-in, session detection, and logout.

## Files

- `pubspec_additions.yaml` — packages + one-time Firebase/Google setup steps
- `lib/services/connectivity_service.dart` — internet check
- `lib/services/auth_service.dart` — Google sign-in, session, sign-out
- `lib/widgets/auth_gate.dart` — routes to Login or Home based on session
- `lib/screens/login_screen.dart` — "Continue with Google" button + states
- `lib/widgets/logout_tile.dart` — drop-in Logout row for Profile/Settings
- `lib/main_example.dart` — how the pieces wire into app startup

## How each requirement is met

1. **Continue with Google button** — `login_screen.dart`, styled as a plain
   outlined button matching typical Material login screens.
2. **Platform-supported secure OAuth** — uses `firebase_auth` +
   `google_sign_in`, Google/Firebase's official Flutter integration.
3. **Secure session on success** — `FirebaseAuth.signInWithCredential`
   creates the session; Firebase persists it in Keychain (iOS) / encrypted
   storage (Android) automatically.
4. **Auto-detect session on relaunch** — `AuthGate` reads
   `authService.currentUser` synchronously on first frame and listens to
   `authStateChanges()` after that, so a returning user goes straight to
   Home with no login prompt.
5. **Logout in Profile/Settings** — `logout_tile.dart`, a single
   `ListTile` you place into the existing screen.
6. **Never stores the Google password** — the app never sees it; Google's
   sign-in flow only ever hands back OAuth tokens, which Firebase manages.
7. **Offline first-time login message** — `auth_service.dart` checks
   connectivity before starting sign-in and returns
   *"Internet connection is required for first-time login."* if offline.
8. **Offline access after first login** — Firebase's cached session is
   read from local storage, not the network, so `currentUser` stays
   available with the device offline. Whatever check your offline-content
   feature already uses against `FirebaseAuth.instance.currentUser` keeps
   working unchanged.
9. **Loading/error states** — `AuthStatus` enum drives the four states
   (Signing in… / Login successful / Login failed / No internet
   connection) shown under the button.

## Setup checklist

1. Add the packages in `pubspec_additions.yaml` to your real `pubspec.yaml`.
2. Run `flutterfire configure` (see comments in that file) to generate
   `firebase_options.dart` and the native config files.
3. Enable the Google provider in Firebase Console → Authentication →
   Sign-in method.
4. Add Android SHA-1/SHA-256 fingerprints in Firebase Console.
5. Add the iOS URL scheme to `Info.plist` (see comments in
   `pubspec_additions.yaml`).
6. Wrap your existing Login/Home decision point with `AuthGate` (see
   `main_example.dart`) and add `LogoutTile` to Profile/Settings.

## Manual test pass

- Fresh install, airplane mode on, tap "Continue with Google" →
  "Internet connection is required for first-time login."
- Turn wifi on, sign in → "Login successful", lands on Home.
- Force-close and reopen the app → opens directly to Home, no login
  screen.
- Turn on airplane mode after being signed in, reopen the app → still
  opens to Home (session is cached locally).
- Tap Logout in Profile/Settings, confirm → returns to Login screen.
- Sign in with a network error mid-flow (e.g. toggle airplane mode
  during the Google picker) → "Login failed" with a message, button
  re-enabled.
