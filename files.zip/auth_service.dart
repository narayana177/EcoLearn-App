import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import 'connectivity_service.dart';

/// UI-facing states for a sign-in attempt. Maps directly onto
/// requirement 9 (Signing in… / Login successful / Login failed /
/// No internet connection).
enum AuthStatus { idle, loading, success, error, noInternet }

class AuthResult {
  final AuthStatus status;
  final String? message;
  const AuthResult(this.status, [this.message]);
}

/// Wraps Firebase Auth + google_sign_in behind a small, testable API.
///
/// Session handling: Firebase Auth persists the signed-in user securely
/// on-device by default (Keychain on iOS, encrypted storage on Android),
/// so `currentUser` / `authStateChanges()` already give "stay logged in
/// across launches" for free — no extra code needed to remember the
/// session, and the Google password itself is never seen or stored by
/// this app; only the OAuth tokens Firebase manages internally.
class AuthService {
  final FirebaseAuth _firebaseAuth;
  final GoogleSignIn _googleSignIn;
  final ConnectivityService _connectivity;

  AuthService({
    FirebaseAuth? firebaseAuth,
    GoogleSignIn? googleSignIn,
    ConnectivityService? connectivity,
  })  : _firebaseAuth = firebaseAuth ?? FirebaseAuth.instance,
        _googleSignIn = googleSignIn ?? GoogleSignIn(),
        _connectivity = connectivity ?? ConnectivityService();

  /// Emits the current user on every auth change, including the cached
  /// user immediately on app start — works fully offline since it reads
  /// local secure storage, not the network.
  Stream<User?> get authStateChanges => _firebaseAuth.authStateChanges();

  /// Synchronous read of any cached session. Use this to seed the first
  /// frame so a returning user never sees a login-screen flash.
  User? get currentUser => _firebaseAuth.currentUser;

  bool get hasExistingSession => _firebaseAuth.currentUser != null;

  Future<AuthResult> signInWithGoogle() async {
    // A returning user with a cached session never reaches this method —
    // it only runs for a fresh sign-in, which needs the network to talk
    // to Google and Firebase.
    final online = await _connectivity.hasConnection();
    if (!online) {
      return const AuthResult(
        AuthStatus.noInternet,
        'Internet connection is required for first-time login.',
      );
    }

    try {
      final googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        // User dismissed the Google account picker — not an error.
        return const AuthResult(AuthStatus.idle);
      }

      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      await _firebaseAuth.signInWithCredential(credential);
      return const AuthResult(AuthStatus.success, 'Login successful');
    } on FirebaseAuthException catch (e) {
      return AuthResult(AuthStatus.error, e.message ?? 'Login failed');
    } catch (_) {
      return const AuthResult(AuthStatus.error, 'Login failed');
    }
  }

  Future<void> signOut() async {
    await Future.wait([
      _firebaseAuth.signOut(),
      _googleSignIn.signOut(),
    ]);
  }
}
