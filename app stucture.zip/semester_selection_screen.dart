import 'package:flutter/material.dart';

import '../data/syllabus_repository.dart';
import '../models/semester.dart';
import '../theme/app_theme.dart';
import 'subject_selection_screen.dart';

class SemesterSelectionScreen extends StatelessWidget {
  final SyllabusRepository repository;

  const SemesterSelectionScreen({super.key, required this.repository});

  @override
  Widget build(BuildContext context) {
    final semesters = repository.getSemesters();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Select Semester'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: semesters.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final semester = semesters[index];
          return _SemesterCard(
            semester: semester,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SubjectSelectionScreen(semester: semester),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _SemesterCard extends StatelessWidget {
  final Semester semester;
  final VoidCallback onTap;

  const _SemesterCard({required this.semester, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.primaryLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${semester.number}',
                  style: const TextStyle(
                    color: AppColors.primaryDark,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  '${_ordinal(semester.number)} Semester',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              const Icon(Icons.chevron_right, color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }

  String _ordinal(int n) {
    const suffixes = {1: 'st', 2: 'nd', 3: 'rd'};
    final suffix = (n >= 11 && n <= 13) ? 'th' : (suffixes[n % 10] ?? 'th');
    return '$n$suffix';
  }
}
