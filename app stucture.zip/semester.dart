import 'subject.dart';

/// One semester's subjects. `hasSyllabus` is false where the C-23
/// syllabus hasn't been supplied yet (currently 1st & 2nd semester) -
/// the UI shows a "coming soon" message instead of inventing subjects.
class Semester {
  final int number;
  final List<Subject> theorySubjects;
  final List<Subject> practicalSubjects;
  final bool hasSyllabus;

  const Semester({
    required this.number,
    this.theorySubjects = const [],
    this.practicalSubjects = const [],
    this.hasSyllabus = true,
  });

  List<Subject> get allSubjects => [...theorySubjects, ...practicalSubjects];
}
