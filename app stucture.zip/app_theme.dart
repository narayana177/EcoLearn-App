import 'package:flutter/material.dart';

/// Central place for EcoLearn's blue-based branding so every screen
/// looks consistent without hardcoding colors per widget.
class AppColors {
  static const primary = Color(0xFF1565C0);
  static const primaryDark = Color(0xFF0D47A1);
  static const primaryLight = Color(0xFFE3F2FD);
  static const surface = Colors.white;
  static const background = Color(0xFFF5F8FC);
  static const textPrimary = Color(0xFF1A1A1A);
  static const textSecondary = Color(0xFF5F6368);
  static const border = Color(0xFFE0E6ED);
}
