import 'package:flutter/material.dart';

import '../models/subject.dart';
import '../theme/app_theme.dart';
import 'content_placeholder_screen.dart';

/// The 10 dashboard entries a subject exposes. Every one currently
/// pushes a simple placeholder — the exam-paper database, offline
/// download and download-progress systems are built in a later step
/// and will replace ContentPlaceholderScreen per section without
/// requiring any change here.
const List<_DashboardItem> _dashboardItems = [
  _DashboardItem('Syllabus', Icons.description_outlined),
  _DashboardItem('Units', Icons.view_module_outlined),
  _DashboardItem('Topics', Icons.topic_outlined),
  _DashboardItem('Study Material', Icons.menu_book_outlined),
  _DashboardItem('Notes', Icons.note_alt_outlined),
  _DashboardItem('Important Questions', Icons.help_outline),
  _DashboardItem('Regular Exam Papers', Icons.assignment_outlined),
  _DashboardItem('Supply Exam Papers', Icons.assignment_late_outlined),
  _DashboardItem('Previous Papers', Icons.history_edu_outlined),
  _DashboardItem('Download for Offline', Icons.download_outlined),
];

class _DashboardItem {
  final String label;
  final IconData icon;
  const _DashboardItem(this.label, this.icon);
}

class SubjectDashboardScreen extends StatelessWidget {
  final Subject subject;

  const SubjectDashboardScreen({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(subject.code),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: Text(
              subject.name,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              itemCount: _dashboardItems.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final item = _dashboardItems[index];
                return _DashboardTile(
                  item: item,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ContentPlaceholderScreen(
                          subject: subject,
                          sectionTitle: item.label,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _DashboardTile extends StatelessWidget {
  final _DashboardItem item;
  final VoidCallback onTap;

  const _DashboardTile({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              Icon(item.icon, color: AppColors.primary, size: 22),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  item.label,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              const Icon(Icons.chevron_right, color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
