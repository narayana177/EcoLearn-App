# EcoLearn — Semester & Subject Navigation (Flutter)

Self-contained slice implementing: Select Semester → Select Subject →
Subject Dashboard → Content (placeholder). Doesn't touch auth, or the
real exam-paper database / offline download system — those come later.

## Files

- `lib/models/subject.dart` — Subject (code, name, isPractical)
- `lib/models/semester.dart` — Semester (theory + practical subjects,
  hasSyllabus flag)
- `lib/data/syllabus_repository.dart` — the C-23 syllabus data, behind
  a `SyllabusRepository` interface
- `lib/theme/app_theme.dart` — shared blue branding colors
- `lib/screens/semester_selection_screen.dart` — Select Semester
- `lib/screens/subject_selection_screen.dart` — Select Subject (theory
  + practical sections, or "coming soon" for sem 1–2)
- `lib/screens/subject_dashboard_screen.dart` — the 10-item dashboard
  per subject
- `lib/screens/content_placeholder_screen.dart` — generic "coming
  soon" screen every dashboard tile opens for now

## Data rules followed

- Only subjects from the supplied C-23 syllabus are included — nothing
  invented for 1st/2nd semester, and 6th semester has only AI-601.
- 1st & 2nd semester show *"Syllabus content will be added soon."*
  instead of a subject list.
- Adding 1st/2nd semester subjects later is a **data-only** change: add
  `Subject(...)` entries and set `hasSyllabus: true` in
  `syllabus_repository.dart`. No screen or navigation code changes.
- `SyllabusRepository` is an interface specifically so this can later
  move to Firestore/a local DB without touching any screen.
- No duplicate subject codes; practicals are grouped separately from
  theory subjects on the Subject Selection screen.

## Navigation flow implemented

Home → `SemesterSelectionScreen` → `SubjectSelectionScreen` →
`SubjectDashboardScreen` → `ContentPlaceholderScreen` (temporary, per
section).

## Wiring into your existing Home screen

Add a button/nav item that pushes the semester screen:

```dart
import 'data/syllabus_repository.dart';
import 'screens/semester_selection_screen.dart';

ElevatedButton(
  onPressed: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SemesterSelectionScreen(
          repository: StaticSyllabusRepository(),
        ),
      ),
    );
  },
  child: const Text('Browse Subjects'),
)
```

## What's intentionally NOT in this step

- Real Syllabus/Units/Topics/Notes/Exam paper content — every dashboard
  tile opens a placeholder that just says "coming soon."
- Offline download and download-progress UI — the "Download for
  Offline" tile is present and navigable, but does nothing yet.
- Any backend/database — subjects are static Dart data for now, ready
  to be swapped for a real data source via `SyllabusRepository`.

## Manual test pass

- Home → Select Semester shows all 6 semesters, no duplicates.
- Tap 1st or 2nd semester → "Syllabus content will be added soon."
- Tap 3rd/4th/5th semester → theory subjects listed first, then a
  "Practical / Lab Subjects" section, each with correct code + name.
- Tap 6th semester → only AI-601 Industrial Training, no extra items.
- Tap any subject → Subject Dashboard shows subject code + name and
  all 10 sections.
- Tap any dashboard item → placeholder screen with that section's
  title and a "coming soon" message.
- Layout, colors, and card style are identical across every semester
  and subject — nothing custom per screen.
