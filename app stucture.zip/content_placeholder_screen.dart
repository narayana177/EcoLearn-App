import 'package:flutter/material.dart';

import '../models/subject.dart';
import '../theme/app_theme.dart';

/// Temporary landing spot for every Subject Dashboard tile. In the next
/// step (exam-paper database + offline download system), this file
/// gets replaced by real per-section screens — subject_dashboard_screen.dart
/// won't need to change since it only knows about section titles, not
/// this screen's internals.
class ContentPlaceholderScreen extends StatelessWidget {
  final Subject subject;
  final String sectionTitle;

  const ContentPlaceholderScreen({
    super.key,
    required this.subject,
    required this.sectionTitle,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(sectionTitle),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.hourglass_empty,
                  size: 40, color: AppColors.textSecondary),
              const SizedBox(height: 16),
              Text(
                '$sectionTitle for ${subject.code} is coming soon.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 15, color: AppColors.textSecondary),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
