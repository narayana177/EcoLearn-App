/// A single subject or lab within a semester.
class Subject {
  final String code; // e.g. "AI-301"
  final String name; // e.g. "Mathematics-II"
  final bool isPractical;

  const Subject({
    required this.code,
    required this.name,
    this.isPractical = false,
  });
}
