import '../models/semester.dart';
import '../models/subject.dart';

/// Abstract so the data source can move from this static list to
/// Firestore / a local DB later without touching any screen code -
/// screens only ever talk to SyllabusRepository, never the raw data.
abstract class SyllabusRepository {
  List<Semester> getSemesters();
  Semester getSemester(int number);
}

/// C-23 Diploma in Artificial Intelligence syllabus, exactly as
/// supplied. 1st and 2nd semester intentionally have empty subject
/// lists and hasSyllabus: false - do not add placeholder/fake
/// subjects here. When that syllabus data is provided, just add
/// Subject entries and flip hasSyllabus to true; no screen changes
/// are needed anywhere else in the app.
class StaticSyllabusRepository implements SyllabusRepository {
  static final List<Semester> _semesters = [
    const Semester(number: 1, hasSyllabus: false),
    const Semester(number: 2, hasSyllabus: false),
    const Semester(
      number: 3,
      theorySubjects: [
        Subject(code: 'AI-301', name: 'Mathematics-II'),
        Subject(code: 'AI-302', name: 'Java Programming'),
        Subject(code: 'AI-303', name: 'Operating Systems'),
        Subject(code: 'AI-304', name: 'Data Structures through C'),
        Subject(code: 'AI-305', name: 'Artificial Intelligence'),
      ],
      practicalSubjects: [
        Subject(
            code: 'AI-306',
            name: 'Java Programming Lab',
            isPractical: true),
        Subject(
            code: 'AI-307',
            name: 'Data Structures through C Lab',
            isPractical: true),
        Subject(
            code: 'AI-308',
            name: 'Computer Networking & Cyber Security Lab',
            isPractical: true),
        Subject(
            code: 'AI-309',
            name: 'Artificial Intelligence Lab using PROLOG',
            isPractical: true),
      ],
    ),
    const Semester(
      number: 4,
      theorySubjects: [
        Subject(code: 'AI-401', name: 'Software Engineering'),
        Subject(code: 'AI-402', name: 'Web Technologies'),
        Subject(code: 'AI-403', name: 'DBMS'),
        Subject(code: 'AI-404', name: 'Python Programming'),
        Subject(code: 'AI-405', name: 'Internet of Things'),
      ],
      practicalSubjects: [
        Subject(
            code: 'AI-406', name: 'Web Technologies Lab', isPractical: true),
        Subject(code: 'AI-407', name: 'DBMS Lab', isPractical: true),
        Subject(
            code: 'AI-408', name: 'Communication Skills', isPractical: true),
        Subject(
            code: 'AI-409',
            name: 'Python Programming Lab',
            isPractical: true),
      ],
    ),
    const Semester(
      number: 5,
      theorySubjects: [
        Subject(
            code: 'AI-501',
            name: 'Industrial Management and Entrepreneurship'),
        Subject(code: 'AI-502', name: 'Computer Vision'),
        Subject(code: 'AI-503', name: 'Natural Language Processing'),
        Subject(
            code: 'AI-504',
            name: 'Artificial Neural Networks and Deep Learning'),
        Subject(code: 'AI-505', name: 'Introduction to Machine Learning'),
      ],
      practicalSubjects: [
        Subject(
            code: 'AI-506', name: 'NLP Lab using Python', isPractical: true),
        Subject(
            code: 'AI-507', name: 'Machine Learning Lab', isPractical: true),
        Subject(code: 'AI-508', name: 'Life Skills', isPractical: true),
        Subject(code: 'AI-509', name: 'Project Work', isPractical: true),
      ],
    ),
    const Semester(
      number: 6,
      theorySubjects: [
        Subject(code: 'AI-601', name: 'Industrial Training'),
      ],
    ),
  ];

  @override
  List<Semester> getSemesters() => _semesters;

  @override
  Semester getSemester(int number) =>
      _semesters.firstWhere((s) => s.number == number);
}
